from reqs import Req
from keys import AESCipher
from keys import RSAKey
import os
import tkinter as tk
import tkinter.messagebox
from tkinter import StringVar
from tkinter import filedialog
import json


DEBUG=True


class MainApplication(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent
        self.sess = Req()
        self.aes = AESCipher()
        self.rsa = RSAKey()
        self.report = {'fields':{'Empty':'Report'}}
        self.pk = -1

        self.login = Login(self)
        self.home = Home(self)
        self.search = Search(self)
        self.encrypt = Encrypt(self)
        self.decrypt = Decrypt(self)
        self.upload = Upload(self)
        self.download = Download(self) # this should be replaced when search & report view is implimented
        self.keymanager = KeyManager(self)
        self.individual = Individual(self)

        self.views = {'login':self.login,
                       'home':self.home,
                       'search':self.search,
                       'encrypt':self.encrypt,
                       'decrypt':self.decrypt,
                       'upload':self.upload,
                       'download':self.download,
                       'keymanager':self.keymanager,
                       'individual':self.individual}

        # self.decrypt.grid_forget()
        # self.encrypt.grid_forget()
        # self.search.grid_forget()
        self.login.grid()


    def passed_login(self):
        self.login.grid_forget()
        #self.login.destroy()
        self.home.grid()


    def go_home(self, leaver):
        self.go_to(leaver, 'home')


    def go_to(self, leaver, dest):
        self.views[leaver].grid_forget()
        #if leaver == 'individual':
        #    self.views[leaver].destroy()
        if dest == 'individual':
            self.views[dest].populate()
        self.views[dest].grid()


class Login(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent
        self.user = StringVar(master=self)
        self.passwd = StringVar(master=self)


        self.L1 = tk.Label(master=self, text="User Name")
        self.L1.grid(row=0, column=0)
        self.E1 = tk.Entry(master=self, textvariable=self.user)
        self.E1.grid(row=0, column=1)
        self.L2 = tk.Label(master=self, text="Password")
        self.L2.grid(row=1, column=0)
        self.E2 = tk.Entry(master=self, textvariable=self.passwd)
        self.E2.grid(row=1, column=1)
        self.B1 = tk.Button(master=self, text="login", command=self.sendLogin)
        self.B1.grid(row=2, column=0, columnspan=2)


    def sendLogin(self):
        if DEBUG:
            ret_code = self.parent.sess.login('norv', 'qwertyuiop')
        else:
            ret_code = self.parent.sess.login(self.user.get(), self.passwd.get())
        if ret_code == 200:
            self.parent.passed_login()
        else:
            tk.messagebox.showinfo("Login Failure", "Username and/or password is incorrect")


class Home(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.go_to_search_button = tk.Button(master=self, text="Search", command=lambda: self.parent.go_to(leaver='home', dest='search'))
        self.go_to_encrypt_button = tk.Button(master=self, text="Encrypt", command=lambda: self.parent.go_to(leaver='home', dest='encrypt'))
        self.go_to_decrypt_button = tk.Button(master=self, text="Decrypt", command=lambda: self.parent.go_to(leaver='home', dest='decrypt'))
        #self.go_to_upload_button = tk.Button(master=self, text="Upload", command=lambda: self.parent.go_to(leaver='home', dest='upload'))
        #self.go_to_download_button = tk.Button(master=self, text="Download", command=lambda: self.parent.go_to(leaver='home', dest='download'))
        self.go_to_keymanager_button = tk.Button(master=self, text="Key Manager", command=lambda: self.parent.go_to(leaver='home', dest='keymanager'))

        self.go_to_search_button.grid(row=0, column=0)
        self.go_to_encrypt_button.grid(row=0, column=1)
        self.go_to_decrypt_button.grid(row=0, column=2)
        #self.go_to_upload_button.grid(row=0, column=3)
        #self.go_to_download_button.grid(row=0, column=4)
        self.go_to_keymanager_button.grid(row=0, column=5)



class Search(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent
        self.searchtext = StringVar(self)
        self.results = []
        self.visible = []
        self.paginate = 10 # RANDOMish
        self.pos = 0

        self.E1 = tk.Entry(master=self, bd=1, textvariable=self.searchtext)
        self.B1 = tk.Button(master=self, text="search", command=self.search)
        self.go_home_button = tk.Button(master=self, text="Home", command=lambda: self.parent.go_to(leaver='search', dest='home'))

        self.E1.grid(row=0, column=0, columnspan=3)
        self.B1.grid(row=0, column=4)
        self.go_home_button.grid(row=1, column=1)


    def search(self):
        self.results = self.parent.sess.search(self.searchtext.get()) # returns list of dictionaries
        self.display_results()


    def display_results(self):
        self.visible = []
        i = self.pos
        # populate visible with buttons
        while i < self.pos + self.paginate and i < len(self.results):
            label_text = str(i+1) + self.gen_name(self.results[i])
            self.visible.append(tk.Button(master=self, text=label_text, command=lambda x=self.results[i]: self.go_to_individual(x), anchor="w"))
            i += 1

        # put all the buttons in the grid
        for i, b in enumerate(self.visible):
            b.grid(row=i+2, column=0, columnspan=4, sticky=tk.W+tk.E)

        # now add previous and next buttons
        self.visible.append(tk.Button(master=self, text="Previous", command=lambda: self.previous()))
        self.visible[-1].grid(row=(len(self.results)-self.pos)%self.paginate+3, column=2, columnspan=1)
        if self.pos == 0:
            self.visible[-1].config(state=tk.DISABLED)
        self.visible.append(tk.Button(master=self, text="Next", command=lambda: self.next()))
        self.visible[-1].grid(row=(len(self.results)-self.pos)%self.paginate+3, column=3, columnspan=1)
        if self.pos + self.paginate >= len(self.results):
            self.visible[-1].config(state=tk.DISABLED)


    def gen_name(self, ind_report):
        bld_str = " | "
        fields = ind_report['fields']
        bld_str += fields['company_name']
        bld_str += " | " + fields['ceo']
        return bld_str


    def go_to_individual(self, ind_report):
        self.parent.report = ind_report
        self.parent.pk = ind_report['pk']
        self.parent.go_to(leaver='search', dest='individual')


    def previous(self):
        self.pos -= self.paginate
        for i, b in enumerate(self.visible):
            b.grid_forget()
            b.destroy()
        self.display_results()


    def next(self):
        self.pos += self.paginate
        for i, b in enumerate(self.visible):
            b.grid_forget()
            b.destroy()
        self.display_results()


class Individual(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.labels = []


    def populate(self):
        for i, key in enumerate(self.parent.report['fields'].keys()):
            self.labels.append(tk.Label(master=self, text=key, anchor="w"))
            self.labels[-1].grid(row=i, column=0, columnspan=1, sticky=tk.W+tk.E)
            if key == 'files_attached':
                self.labels.append(tk.Label(master=self, text=len(json.loads(self.parent.sess.getReportFiles(str(self.parent.pk)))), anchor="w"))
                self.labels[-1].grid(row=i, column=1, columnspan=1, sticky=tk.W+tk.E)
            else:
                self.labels.append(tk.Label(master=self, text=self.parent.report['fields'][key], anchor="w"))
                self.labels[-1].grid(row=i, column=1, columnspan=1, sticky=tk.W+tk.E)


        self.labels.append(tk.Button(master=self, text="Home", command=lambda: self.parent.go_to(leaver='individual', dest='home')))
        self.labels[-1].grid(row=len(self.parent.report['fields']), column=0, columnspan=1, sticky=tk.W+tk.E)
        self.labels.append(tk.Button(master=self, text="Back", command=lambda: self.parent.go_to(leaver='individual', dest='search')))
        self.labels[-1].grid(row=len(self.parent.report['fields']), column=1, columnspan=1, sticky=tk.W+tk.E)
        self.labels.append(tk.Button(master=self, text="Attach Files", command=lambda: self.upload()))
        self.labels[-1].grid(row=len(self.parent.report['fields']), column=2, columnspan=1, sticky=tk.W+tk.E)
        self.labels.append(tk.Button(master=self, text="Attach Encrypted Files", command=lambda: self.encupload()))
        self.labels[-1].grid(row=len(self.parent.report['fields']), column=3, columnspan=1, sticky=tk.W+tk.E)
        self.labels.append(tk.Button(master=self, text="Download Files", command=lambda: self.download()))
        self.labels[-1].grid(row=len(self.parent.report['fields']), column=4, columnspan=1, sticky=tk.W+tk.E)


    def download(self):
        filenames = json.loads(self.parent.sess.getReportFiles(str(self.parent.pk)))
        path = filedialog.askdirectory() + "/"
        if path:
            for fname in filenames:
                with open(path + fname.split("/")[-1], 'wb+') as f:
                    f.write(self.parent.sess.downloadFile(fname))
                tk.messagebox.showinfo("File downloaded", "File downloaded and saved to " + path + fname.split("/")[-1])


    def upload(self):
        in_filename = filedialog.askopenfilename()
        if tk.messagebox.askyesno("Upload", "Uploading " + in_filename + "\nIs that ok?"):
            self.parent.sess.attachFile(str(self.parent.pk), in_filename)


    def encupload(self):
        if not self.parent.aes.exists:
            self.parent.aes.newAESKey()

        in_filename = filedialog.askopenfilename()

        # encrypt file
        self.parent.aes.encrypt_file(in_filename)
        self.parent.sess.attachFile(str(self.parent.pk), in_filename + '.enc')
        # delete file
        os.remove(in_filename + '.enc')

        # save key to temporary file
        self.parent.aes.saveKeyToFile(in_filename + '.enc' + '.key')
        self.parent.sess.attachFile(str(self.parent.pk), in_filename + '.enc' + '.key')
        # delete temporary keyfile
        os.remove(in_filename + '.enc' + '.key')


class Decrypt(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.in_file_name_var = StringVar(self)
        self.in_file_name_var.set("No file selected")
        self.rsa_file_name_var = StringVar(self) # not using yet
        self.in_filename = None
        self.out_filename = None
        self.rsa_filename = None

        # in_label | in_filename | pick_infile_button
        # out_label| outfilename | pick_outfile_button
        self.in_label = tk.Label(master=self, text="File to decrypt:");
        self.in_file_name = tk.Label(master=self, textvariable=self.in_file_name_var)
        self.pick_infile_button = tk.Button(master=self, text="Choose File", command=self.pick_infile)
        self.decrypt_button = tk.Button(master=self, text="decrypt", command=self.decrypt)
        self.go_home_button = tk.Button(master=self, text="Home", command=lambda: self.parent.go_to(leaver='decrypt',dest='home'))

        self.in_label.grid(row=0, column=0, columnspan=1)
        self.in_file_name.grid(row=0, column=1, columnspan=2)
        self.pick_infile_button.grid(row=0, column=3, columnspan=1)
        self.decrypt_button.grid(row=1, column=3, columnspan=1)
        self.go_home_button.grid(row=1, column=1, columnspan=1)


    def pick_infile(self):
        self.in_filename = filedialog.askopenfilename()
        self.in_file_name_var.set(self.in_filename)


    def decrypt(self):
        if self.in_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to decrypt")
        else:
            outfilename = os.path.splitext(self.in_filename)[0]
            if tk.messagebox.askyesno("Decrypt", "Will decrypt to " + outfilename + "\nIs that ok?"):
                self.parent.aes.decrypt_file(self.in_filename)


class Encrypt(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.in_file_name_var = StringVar(self)
        self.in_file_name_var.set("No file selected")
        self.rsa_file_name_var = StringVar(self) # not using yet
        self.in_filename = None
        self.out_filename = None
        self.rsa_filename = None

        # in_label | in_filename | pick_infile_button
        # out_label| outfilename | pick_outfile_button
        self.in_label = tk.Label(master=self, text="File to encrypt:");
        self.in_file_name = tk.Label(master=self, textvariable=self.in_file_name_var)
        self.pick_infile_button = tk.Button(master=self, text="Choose File", command=self.pick_infile)
        self.decrypt_button = tk.Button(master=self, text="Encrypt", command=self.encrypt)
        self.go_home_button = tk.Button(master=self, text="Home", command=self.go_home)

        self.in_label.grid(row=0, column=0, columnspan=1)
        self.in_file_name.grid(row=0, column=1, columnspan=2)
        self.pick_infile_button.grid(row=0, column=3, columnspan=1)
        self.decrypt_button.grid(row=1, column=3, columnspan=1)
        self.go_home_button.grid(row=1, column=1, columnspan=1)


    def pick_infile(self):
        self.in_filename = filedialog.askopenfilename()
        self.in_file_name_var.set(self.in_filename)


    def encrypt(self):
        if self.in_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to encrypt")
        else:
            outfilename = self.in_filename + '.enc'
            if tk.messagebox.askyesno("Encrypt", "Will encrypt to " + outfilename + "\nIs that ok?"):
                self.parent.aes.encrypt_file(self.in_filename)


    def go_home(self):
        self.parent.go_home(leaver='encrypt')


class Upload(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.in_file_name_var = StringVar(self)
        self.in_file_name_var.set("No file selected")
        self.in_filename = None

        self.in_label = tk.Label(master=self, text="File to upload:");
        self.in_file_name = tk.Label(master=self, textvariable=self.in_file_name_var)
        self.pick_infile_button = tk.Button(master=self, text="Choose File", command=self.pick_infile)
        self.upload_button = tk.Button(master=self, text="Upload", command=self.upload)
        #self.enc_upload_button = tk.Button(master=self, text="Encrypt and Upload", command=self.encupload)
        self.go_home_button = tk.Button(master=self, text="Home", command=self.go_home)

        self.in_label.grid(row=0, column=0, columnspan=1)
        self.in_file_name.grid(row=0, column=1, columnspan=2)
        self.pick_infile_button.grid(row=0, column=3, columnspan=1)
        self.upload_button.grid(row=1, column=3, columnspan=1)
        #self.enc_upload_button.grid(row=1, column=2, columnspan=1)
        self.go_home_button.grid(row=1, column=1, columnspan=1)


    def pick_infile(self):
        self.in_filename = filedialog.askopenfilename()
        self.in_file_name_var.set(self.in_filename)


    def upload(self):
        # actually going to attach a file
        if self.in_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to upload")
        else:
            if tk.messagebox.askyesno("Upload", "Uploading " + self.in_filename + "\nIs that ok?"):
                #self.parent.sess.uploadFile(self.in_filename)
                self.parent.sess.attachFile(str(self.parent.pk), self.in_filename)


    def encupload(self):
        if self.in_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to upload")
        else:
            if tk.messagebox.askyesno("Upload", "Uploading " + self.in_filename + "\nIs that ok?"):
                # if not self.parent.aes.exists:
                #     self.parent.aes.newAESKey()
                # # encrypt file
                # self.parent.aes.encrypt_file(self.in_filename)
                # self.parent.sess.uploadFile(self.in_filename + '.enc')
                # # delete file
                # os.remove(self.in_filename + '.enc')
                # # save key to temporary file
                # self.parent.aes.saveKeyToFile(self.in_filename + '.enc' + '.key')
                # self.parent.sess.uploadFile(self.in_filename + '.enc' + '.key')
                # # delete temporary keyfile
                # os.remove(self.in_filename + '.enc' + '.key')

                ####################

                if not self.parent.aes.exists:
                    self.parent.aes.newAESKey()
                # encrypt file
                self.parent.aes.encrypt_file(self.in_filename)
                self.parent.sess.attachFile(str(self.parent.pk), self.in_filename + '.enc')
                # delete file
                os.remove(self.in_filename + '.enc')
                # save key to temporary file
                self.parent.aes.saveKeyToFile(self.in_filename + '.enc' + '.key')
                self.parent.sess.uploadFile(self.in_filename + '.enc' + '.key')
                # delete temporary keyfile
                os.remove(self.in_filename + '.enc' + '.key')


    def go_home(self):
        self.parent.go_home(leaver='upload')


class Download(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.in_file_name_var = StringVar(self)
        self.in_file_name_var.set("No file selected")
        self.get_file_name_var = StringVar(self)
        self.get_file_name_var.set("Enter Name")
        self.in_filename = None

        self.in_label = tk.Label(master=self, text="Save location:");
        self.in_file_name = tk.Label(master=self, textvariable=self.in_file_name_var)
        self.get_file_name_entry = tk.Entry(master=self, textvariable=self.get_file_name_var)
        self.pick_infile_button = tk.Button(master=self, text="Choose Location", command=self.pick_infile)
        self.download_button = tk.Button(master=self, text="Download", command=self.download)
        self.enc_download_button = tk.Button(master=self, text="Download Encrypted and Unencrypt", command=self.encdownload)
        self.go_home_button = tk.Button(master=self, text="Home", command=self.go_home)

        self.in_label.grid(row=0, column=0, columnspan=1)
        self.in_file_name.grid(row=0, column=1, columnspan=2)
        self.get_file_name_entry.grid(row=1, column=1, columnspan=1)
        self.pick_infile_button.grid(row=0, column=3, columnspan=1)
        self.download_button.grid(row=1, column=3, columnspan=1)
        self.enc_download_button.grid(row=1, column=2, columnspan=1)
        self.go_home_button.grid(row=1, column=0, columnspan=1)


    def pick_infile(self):
        self.in_filename = filedialog.asksaveasfilename()
        self.in_file_name_var.set(self.in_filename)


    def download(self):
        if self.in_filename == None or self.get_file_name_var.get() == "Enter Name":
            tk.messagebox.showinfo("File not selected", "Please select a file to save to")
        else:
            with open(self.in_filename, 'wb+') as f:
                f.write(self.parent.sess.downloadFile(self.get_file_name_var.get()))
            tk.messagebox.showinfo("File downloaded", "File downloaded and saved to " + self.in_filename)


    def encdownload(self):
        if self.in_filename == None or self.get_file_name_var.get() == "Enter Name":
            tk.messagebox.showinfo("File not selected", "Please select a file to save to")
        else:
            # download encrypted file
            with open(self.in_filename + '.enc', 'wb+') as f:
                f.write(self.parent.sess.downloadFile(self.get_file_name_var.get() + '.enc'))
            # download key file
            with open(self.in_filename + '.enc' + '.key', 'wb+') as f:
                f.write(self.parent.sess.downloadFile(self.get_file_name_var.get() + '.enc' + '.key'))

            # load key
            aes = AESCipher()
            aes.loadKeyFromFile(self.in_filename + '.enc' + '.key')

            # decrypt file
            aes.decrypt_file(self.in_filename + '.enc') # saves to self.in_filename

            # delete temp files
            os.remove(self.in_filename + '.enc')
            os.remove(self.in_filename + '.enc' + '.key')

            tk.messagebox.showinfo("File downloaded", "File downloaded and saved to " + self.in_filename)


    def go_home(self):
        self.parent.go_home(leaver='upload')


class KeyManager(tk.Frame):
    def __init__(self, parent, *args, **kwargs):
        tk.Frame.__init__(self, parent, *args, **kwargs)
        self.parent = parent

        self.in_filename = None
        self.out_filename = None

        self.choose_key_file_rsa = tk.Button(master=self, text="Load RSA keyfile", command=self.loadkeyrsa)
        self.choose_key_file_aes = tk.Button(master=self, text="Load AES keyfile", command=self.loadkeyaes)
        self.gen_new_key_rsa = tk.Button(master=self, text="Generate new RSA key", command=self.genkeyrsa)
        self.gen_new_key_aes = tk.Button(master=self, text="Generate new AES key", command=self.genkeyaes)
        self.save_key_file_rsa = tk.Button(master=self, text="Save current RSA key", command=self.savekeyrsa)
        self.save_key_file_aes = tk.Button(master=self, text="Save current AES key", command=self.savekeyaes)
        self.go_home_button = tk.Button(master=self, text="Home", command=self.go_home)

        self.choose_key_file_rsa.grid(row=1, column=0, columnspan=1)
        self.choose_key_file_aes.grid(row=2, column=0, columnspan=1)
        self.gen_new_key_rsa.grid(row=1, column=1, columnspan=1)
        self.gen_new_key_aes.grid(row=2, column=1, columnspan=1)
        self.save_key_file_rsa.grid(row=1, column=2, columnspan=1)
        self.save_key_file_aes.grid(row=2, column=2, columnspan=1)
        self.go_home_button.grid(row=3, column=1, columnspan=1)

    
    def loadkeyrsa(self):
        self.in_filename = filedialog.askopenfilename()
        if self.in_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to load")
        else:
            self.parent.rsa.loadKeyFromFile(self.in_filename)

    
    def loadkeyaes(self):
        self.in_filename = filedialog.askopenfilename()
        if self.in_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to load")
        else:
            self.parent.aes.loadKeyFromFile(self.in_filename)

    
    def genkeyrsa(self):
        self.parent.rsa.genNewKey()

    
    def genkeyaes(self):
        self.parent.aes.newAESKey()

    
    def savekeyrsa(self):
        self.out_filename = filedialog.asksaveasfilename()
        if self.out_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to save to")
        self.parent.rsa.saveKeyToFile(self.out_filename)

    
    def savekeyaes(self):
        self.out_filename = filedialog.asksaveasfilename()
        if self.out_filename == None:
            tk.messagebox.showinfo("File not selected", "Please select a file to save to")
        self.parent.aes.saveKeyToFile(self.out_filename)


    def go_home(self):
        self.parent.go_home(leaver='keymanager')



top = tk.Tk()
MainApplication(parent=top).pack()

top.mainloop()