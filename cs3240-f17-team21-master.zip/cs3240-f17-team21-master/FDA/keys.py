# for doing encryption, decryption, handshakes
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES
from Crypto import Random
import os
import struct


class RSAKey:
    def __init__(self):
        self.key = None
        self.exists = False

        
    def genNewKey(self):
        random_generator = Random.new().read
        self.setKey(RSA.generate(4096, random_generator))


    def loadKeyFromFile(self, filename='./keys/mykey.pem'):
        self.readKeyFromFile(filename)


    def readKeyFromFile(self, filename='./keys/mykey.pem'):
        with open(filename, 'rb') as f:
            self.setKey(RSA.importKey(f.read()))


    def writeKeyToFile(self, filename='./keys/mykey.pem'):
        self.saveKeyToFile(filename)


    def saveKeyToFile(self, filename='./keys/mykey.pem'):
        with open(filename, 'wb+') as f:
            f.write(self.key.exportKey('PEM'))


    def setKey(self, key):
        self.key = key
        self.exists = True


    def encrypt(self, data):
        if not self.exists:
            raise AttributeError("RSA key has not been generated or loaded")
        pub_key = self.key.publickey()
        enc_data = pub_key.encrypt(data, 32) # 32 might need to be randomized, unsure
        return enc_data

    def decrypt(self, enc_data):
        if not self.exists:
            raise AttributeError("RSA key has not been generated or loaded")
        return self.key.decrypt(enc_data)


class AESCipher:
    def __init__(self, key=None):
        self.key = key
        self.exists = False


    def newAESKey(self, size=32):
        self.setKey(Random.new().read(size))


    def loadKeyFromFile(self, filename='./keys/mykey.aes'):
        self.readKeyFromFile(filename)


    def readKeyFromFile(self, filename='./keys/mykey.aes'):
        with open(filename, 'rb') as f:
            self.setKey(f.read())


    def writeKeyToFile(self, dest='./keys/mykey.aes'):
        self.saveKeyToFile(dest)


    def saveKeyToFile(self, dest='./keys/mykey.aes'):
        with open(dest, 'wb+') as f:
            f.write(self.getKey())


    def setKey(self, key):
        self.key = key
        self.exists = True


    def getKey(self):
        return self.key


    def encrypt_file(self, in_filename, out_filename=None):
        if not self.exists:
            raise AttributeError("AES key has not been generated or loaded")
        if not out_filename:
            out_filename = in_filename + '.enc'

        bs = AES.block_size
        chunksize = bs * 1024

        iv = Random.new().read(bs)
        encryptor = AES.new(self.key, AES.MODE_CBC, iv)
        filesize = os.path.getsize(in_filename)

        with open(in_filename, 'rb') as infile:
            with open(out_filename, 'wb') as outfile:
                outfile.write(struct.pack('<Q', filesize))
                outfile.write(iv)

                while True:
                    chunk = infile.read(chunksize)
                    if len(chunk) == 0:
                        break
                    elif len(chunk) % bs != 0:
                        chunk += b' ' * (bs - len(chunk) % bs)

                    outfile.write(encryptor.encrypt(chunk))


    def decrypt_file(self, in_filename, out_filename=None):
        if not self.exists:
            raise AttributeError("AES key has not been generated or loaded")
        if not out_filename:
            out_filename = os.path.splitext(in_filename)[0]

        bs = AES.block_size
        chunksize = bs * 1024

        with open(in_filename, 'rb') as infile:
            originalsize = struct.unpack('<Q', infile.read(struct.calcsize('Q')))[0]
            iv = infile.read(bs)
            decryptor = AES.new(self.key, AES.MODE_CBC, iv)

            with open(out_filename, 'wb') as outfile:
                while True:
                    chunk = infile.read(chunksize)
                    if len(chunk) == 0:
                        break
                    outfile.write(decryptor.decrypt(chunk))
                outfile.truncate(originalsize)


if __name__ == '__main__':
    aes = AESCipher()
    aes.newAESKey()
    aes.saveKeyToFile()
    aes2 = AESCipher()
    aes2.readKeyFromFile()
    aes.encrypt_file('./test/test.txt')
    aes2.decrypt_file('./test/test.txt.enc', './test/test.txt.dec')