import requests
import json


DEBUG = True


class Req():
    def __init__(self):
        # session object is what holds cookies and other things acrss requests
        self.s = requests.Session()

        # dictionary of urls to access, will grow as features are added
        self.urls = {
        'login':'http://localhost:8000/account/login/',
        'profile':'http://localhost:8000/account/profile/',
        'upload':'http://localhost:8000/account/upload/',
        'download':'http://localhost:8000/account/download/',
        'search':'http://localhost:8000/account/search_results_api/?q=',
        'ind_report':'http://localhost:8000/account/individualReportApi/',
        'ind_report_files':'http://localhost:8000/account/individualReportApi/files/',
        'attach':'http://localhost:8000/account/individualReport/attach/',
        'create':'http://localhost:8000/account/submitReport/'
        }

        # get login to establish csrftoken
        self.s.get(self.urls['login'])


    def login(self, user, passwd):
        # build up login data first
        login_data = {'username':user, 'password':passwd, 'csrfmiddlewaretoken':self.s.cookies.get('csrftoken')}

        # now make actual request, this will update session as necessary
        r = self.s.post(self.urls['login'], data=login_data)
        if DEBUG:
            print('user:', user)
            print('passwd', passwd)
            print(r.status_code)
        return r.status_code


    def viewProfile(self):
        # build data from cookies
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))
        url = self.urls['profile']

        # now make request
        r = self.s.post(url, data=sess_data)
        return r.text


    def uploadFile(self, filename):
        # build data from cookies
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))

        # now set up urls and such
        url = self.urls['upload']
        #url = 'http://httpbin.org/post'
        files = {'document': open(filename, 'rb')}
        r = self.s.post(url, data=sess_data, files=files)
        return r.text


    def downloadFile(self, filename):
        # build data from cookies
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))

        url = self.urls['download'] + filename
        r = self.s.get(url, data=sess_data)
        return r.content


    def search(self, query):
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))

        url = self.urls['search'] + query.replace(' ', '+')
        r = self.s.get(url, data=sess_data)
        return json.loads(r.json())


    def getReport(self, pk):
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))

        url = self.urls['ind_report'] + pk + "/"
        r = self.s.get(url, data=sess_data)
        return r.json()


    def getReportFiles(self, pk):
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))

        url = self.urls['ind_report_files'] + pk + "/"
        r = self.s.get(url, data=sess_data)
        return r.json()


    def attachFile(self, pk, filename):
        # build data from cookies
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))

        # now set up urls and such
        url = self.urls['attach'] + pk + "/"
        files = {'files_attached': open(filename, 'rb')}

        r = self.s.post(url, data=sess_data, files=files)
        return r.text


    def createReport(self, values):
        # build data from cookies
        sess_data = dict(sessionid=self.s.cookies.get('sessionid'), csrfmiddlewaretoken=self.s.cookies.get('csrftoken'))
        data = {**sess_data, **values}

        url = self.urls['create']

        r = self.s.post(url, data=data)
        return r.text



    def attachFiles(self, pk, filenames):
        for fname in filenames:
            self.attachFile(pk, fname)





if __name__ == '__main__':
    # with requests.Session() as s:
    #     login_url = 'http://localhost:8000/account/login/'
    #     profile_url = 'http://localhost:8000/account/profile/'
    #     s.get(login_url)
    #     csrftoken = s.cookies['csrftoken']
    #     login_data = {'username':'norv', 'password':'qwertyuiop', 'csrfmiddlewaretoken':s.cookies.get('csrftoken')}
    #     r1 = s.post(login_url,data=login_data)
    #     print(r1.text)
    #     print(s.cookies.keys())
    #     r = s.post(profile_url, data=dict(sessionid=s.cookies.get('sessionid'), csrfmiddlewaretoken=s.cookies.get('csrftoken')))
    #     print(r.text)
    tr = Req()
    tr.login('norv', 'qwertyuiop')
    data = {"report_name": "test", "company_name": "asdf", "ceo": "asdf", "phone_num": 1234567890, "company_email": "asdf@asdf.asdf", "company_location": "asdf", "company_country": "fdsa", "sector": "asdf", "industry": "fdsa", "current_projects": "fdsa", "private_report": False}
    for i in range(27):
        print(tr.createReport(data))