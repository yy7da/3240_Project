# cs3240-f17-team21
Repo for final project in CS 3240

For the projectb to work, you must:
pip install psycopg2
