# Task List

## Samuel
* Simple Custom Homepage w/ Login feature (https://github.com/Sadeio/DjangoLoginHomepage)
* pms in django (Required: the Users have to be created first.)

## Rebecca
* searching (Explored: but need reports to be implemented)

## Elli
* encryption (Explored)
* created initial site

## Will
* file downloading

## All
* Come up with issues/stories
