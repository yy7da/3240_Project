from django.contrib import admin
from accounts.models import UserProfile #ignore the read lines
from accounts.models import Message, Report, Friend, Group #ignore the read lines

# Register your models here.
admin.site.register(Friend)
admin.site.register(UserProfile)
admin.site.register(Message)
admin.site.register(Report)
admin.site.register(Group)
