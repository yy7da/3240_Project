from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.forms import ModelForm
from .models import Message, Report, Document, Group

from django.db import OperationalError

class RegistrationForm(UserCreationForm):
    # Make the email field a required field
    email = forms.EmailField(required=True)
    user_type = forms.ChoiceField(choices=(('0', 'Company User'), ('1', 'Investor User')), widget=forms.RadioSelect(),
                                  required=True)

    class Meta:
        model = User
        fields = (
            'username',
            'first_name',
            'last_name',
            'email',
            'password1',
            'password2',
            'user_type'
        )

    def save(self, commit=True):
        user = super(RegistrationForm, self).save(commit=False)
        user.first_name = self.cleaned_data[
            'first_name']  # makes sure there's nothing like SQlite that can be put in here
        user.last_name = self.cleaned_data['last_name']
        user.email = self.cleaned_data['email']
        # user.user_type = int(self.cleaned_data['user_type'])
        # print('og:',self.cleaned_data['user_type'])
        if commit:
            user.save()  # Saves to SQLite database

        return user


class EditProfileForm(UserChangeForm):
    class Meta:
        model = User
        fields = {
            'email',
            'first_name',
            'last_name',
            'password'
        }


class MessageForm(ModelForm):
    class Meta:
        model = Message
        fields = {
            'recipient',
            'subject',
            'message_text'
        }


class FileFieldForm(ModelForm):
    files_attached = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=False)
    class Meta:
        model=Report
        fields = ('files_attached',)

        
class ReportForm(ModelForm):
    files_attached = forms.FileField(widget=forms.ClearableFileInput(attrs={'multiple': True}), required=False)
    class Meta:
        model=Report
        exclude = ('the_timestamp','owner',)


class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ('description', 'document')


class GroupForm(ModelForm):

    class Meta:
        model = Group
        fields={'name',}


class UserListForm(forms.Form):

    try:
        options = forms.MultipleChoiceField(
            choices=[(option.pk, option.username) for option in User.objects.all()],
            widget=forms.CheckboxSelectMultiple(),
            # label="Choose from the following members",
        )
    except OperationalError:
        options = None

class EditReportForm(ReportForm):
    class Meta:
        model = Report
        fields = {
            'company_name',
            'ceo',
            'phone_num',
            'company_email',
            'company_location',
            'company_country',
            'sector',
            'industry',
            'current_projects',
        }


class InactiveForm(forms.Form):

    try:
        options = forms.MultipleChoiceField(
            choices=[(option.pk, option.username) for option in User.objects.filter(is_active=False)],
            widget=forms.CheckboxSelectMultiple(),
            # label="Choose from the following members",
        )
    except OperationalError:
        options = None
