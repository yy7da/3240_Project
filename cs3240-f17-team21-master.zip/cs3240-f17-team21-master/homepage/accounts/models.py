from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.forms import ModelForm
from django.dispatch import receiver
from datetime import datetime
from Crypto.PublicKey import RSA
from django.shortcuts import HttpResponse

# Create your models here.


class UserProfile(models.Model):
    user = models.OneToOneField(User)  # A foreign key
    description = models.CharField(max_length=100, default='')
    company = models.CharField(max_length=100, default='')
    website = models.URLField(default='')
    group = models.CharField(max_length=100, default='')
    user_type = models.IntegerField(default=3)
    is_site_manager = models.BooleanField(default=False)
    pub_key = models.TextField()
    def __str__(self):  # allow the names of the users to be visisle in the admin
        return self.user.username

    def is_company(self):
        return self.user_type == 0

    def is_investor(self):
        return self.user_type == 1

    def is_sm(self):
        return self.is_site_manager

    @receiver(post_save, sender=User)
    def create_user_profile(sender, instance, created, **kwargs):
        if created:
            UserProfile.objects.create(user=instance)

    @receiver(post_save, sender=User)
    def save_user_profile(sender, instance, **kwargs):
        instance.userprofile.save()


class Message(models.Model):
    # message_num = models.AutoField(primary_key=True)
    sender = models.CharField(max_length=200)
    recipient = models.CharField(max_length=200)
    send_date = models.DateTimeField('Date sent')
    subject = models.CharField(max_length=200)
    message_text = models.TextField(max_length=500)
    was_read = models.BooleanField(default=False)


class MessageForm(ModelForm):
    class Meta:
        model = Message
        exclude = {
            'sender', 'send_date', 'was_read'
        }


class Report(models.Model):
    report_name = models.CharField(max_length=100, default='')
    company_name = models.CharField(max_length=250)
    ceo = models.CharField(max_length=75)
    phone_num = models.PositiveIntegerField()
    company_email = models.EmailField(max_length=300)
    company_location = models.CharField(max_length=300)
    company_country = models.CharField(max_length=100)
    sector = models.CharField(max_length=100)
    industry = models.CharField(max_length=200)
    current_projects = models.TextField()
    private_report = models.BooleanField()
    files_attached = models.FileField(upload_to='documents/')
    the_timestamp = models.DateTimeField(default=datetime.now)
    owner = models.ForeignKey(User, null=True)

    file_names = []


def user_directory_path(instance, filename):
    # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
    return 'user_{0}/{1}'.format(instance.created_by.id, filename)


class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    # add a connection to current user for file paths

class Friend(models.Model):
    users = models.ManyToManyField(User)
    current_user = models.ForeignKey(User, related_name='owner', null=True)

    @classmethod
    def make_friend(cls, current_user, new_friend):
        friend, created = cls.objects.get_or_create(
            current_user=current_user
        )
        friend.users.add(new_friend)

    @classmethod
    def lose_friend(cls, current_user, new_friend):
        friend, created = cls.objects.get_or_create(
            current_user=current_user
        )
        friend.users.remove(new_friend)


class Group(models.Model):
    name = models.CharField(max_length=100, default="Group Name")
    creator = models.CharField(max_length=100)
    permissions = models.ManyToManyField(User)
    reports = models.ManyToManyField(Report)
