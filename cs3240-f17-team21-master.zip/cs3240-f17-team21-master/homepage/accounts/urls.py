from django.conf.urls import url, include
from . import views #Look in folder in the level of account and homepage for a views file
from django.contrib.auth.views import login, logout, password_reset, password_reset_done, password_reset_confirm, password_reset_complete
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    url(r'^$', views.home),
    url(r'^home/$', views.home),
    url(r'^login/$', login, {'template_name': 'accounts/login.html'}),
    url(r'^logout/$', logout, {'template_name': 'accounts/logout.html'}),
    url(r'^register/$', views.register, name='register'),
    url(r'^profile/$', views.view_profile, name='view_profile'),
    url(r'^profile/(?P<pk>\d+)/$', views.view_profile, name='view_profile_with_pk'),
    url(r'^profile/edit/$', views.edit_profile, name='edit_profile'),
    url(r'^change-password/$', views.change_password, name='change_password'),
    #goes back here
    url(r'^search_results/$', views.get_queryset, name='search_list_view'),
    url(r'^search_results_api/$', views.get_queryset_api, name='search_list_view_api'),
    url(r'^messages/$', views.messages, name='messages'),
    url(r'^sendMessage/$', views.sendMessage, name='sendMessage'),
    url(r'^individualMessage/(?P<message_id>[0-9]+)(?:/(?P<delete>delete)/)?$', views.individualMessage, name='individualMessage'),
    url(r'^reports/$', views.reports, name='reports'),
    url(r'^individualReport/(?P<report_id>[0-9]+)/$', views.individualReport, name='indReport'),
    url(r'^individualReportApi/(?P<report_id>[0-9]+)/$', views.individualReportApi, name='indReportApi'),
    url(r'^individualReportApi/files/(?P<report_id>[0-9]+)/$', views.getFilesAttachedToIndividual, name='indReportGetFilesApi'),
    url(r'^individualReport/attach/(?P<report_id>[0-9]+)/$', views.attachToIndividualReport, name='attachIndReport'),
    url(r'^individualReport/(?P<report_id>[0-9]+)(?:/(?P<delete>delete)/)?$', views.individualReport, name='delRep'),
    url(r'^display_key/$', views.display_key, name='display_key'),

    url(r'^submitReport/$', views.submitReport, name='submitreport'),
    url(r'^upload/', views.model_form_upload, name='model_form_upload'),
    url(r'^download/(?P<filename>[_\-a-zA-Z0-9\./]+)/$', views.download_file, name='download_file'),
    url(r'^connect/(?P<operation>.+)/(?P<pk>\d+)/$', views.change_friends, name='change_friends'),
    
    url(r'^addGroup/$', views.addGroup, name='addGroup'),
    url(r'^groups/$', views.groups, name='groups'),
    url(r'^groups_manager/$', views.groups_manager, name='groups_manager'),
    url(r'^individualGroup/(?P<group_id>[0-9]+)/$', views.individualGroup, name='individualGroup'),
    url(r'^individualGroup/(?P<group_id>[0-9]+)(?:/(?P<delete>delete)/)?$', views.individualGroup, name='delGroup'),
    url(r'^addGroupMember/(?P<group_id>[0-9]+)/$', views.addGroupMember, name='addGroupMember'),
    url(r'^addGroupReport/(?P<group_id>[0-9]+)/$', views.addGroupReport, name='addGroupReport'),
    url(r'^removeGroupMember/(?P<group_id>[0-9]+)(?:/(?P<user_id>[0-9]+)/)?$', views.removeGroupMember, name='removeGroupMember'),

    url(r'^editReport/(?P<report_id>[0-9]+)/$', views.editReport, name='editReport'),
    url(r'^smPermission/$', views.smPermission, name='smPermission'),
    url(r'^smSuspend/$', views.smSuspend, name='smSuspend'),
    url(r'^smUnsuspend/$', views.smUnsuspend, name='smUnsuspend'),


]

if settings.DEBUG:
    urlpatterns+= static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns+= static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

'''
  url(r'^reset-password/$', password_reset, name='reset_password'),
  url(r'^reset-password/done/$', password_reset_done, name='password_reset_done'),#{'template_name': 'accounts/password_reset_done.html'}),
  url(r'^reset-password/confirm/(?P<uidb64>[0-9A-Za-z]+)-(?P<token>,+)/$',
      password_reset_confirm, name='reset_password_confirm'),
  url(r'^reset-password/complete/$', password_reset_complete,
      name='password_reset_complete'),

  '''