from django.shortcuts import render, redirect, HttpResponse
from django.http import FileResponse
from accounts.forms import (  # ignore the red marks. It still works fine
    RegistrationForm,
    EditProfileForm,
    MessageForm,
    ReportForm,
    DocumentForm,
    GroupForm,
    UserListForm,
    FileFieldForm,
    EditReportForm,
    InactiveForm,
)
from .models import Message, UserProfile, Report, Friend, Group

from django.contrib import messages
from array import array
from django.contrib.auth.forms import UserChangeForm, PasswordChangeForm
from django.contrib.auth import update_session_auth_hash  # keeps user logged in even after change pw
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Message, UserProfile, Report, Friend
from django.contrib.postgres.search import SearchQuery, SearchRank, SearchVector
from django.views.generic import ListView
from django.db.models import Q
from django.http import JsonResponse
from django.core import serializers
import datetime
import string
from Crypto.PublicKey import RSA
import os
import json

# Create your views here.

@login_required()
def home(request):
    received = Message.objects.all().filter(recipient=request.user.username, was_read=False)
    #if(len(received)>0):
    messageAlert = len(received)
        #= "<a href='/account/messages'>You have new messages!</a>"
    #else:
     #   messageAlert = "<a href='/account/messages'>You have no new messages.</a>"
    users = User.objects.exclude(id=request.user.id)

    if False: #len(Friend.objects.all()) > 0:
        friend = Friend.objects.get(current_user=request.user) #change back to get
        friends = friend.users.all()
    else:
        friends = Friend.objects.all()

    context = {'messageAlert':messageAlert, 'users':users, 'friends':friends}


    return render(request, 'accounts/home.html', context)

def gen_key():
        key = RSA.generate(2048)
        with open("key_file.pem", "wb+") as f:
            f.write(key.exportKey("PEM"))
        # return HttpResponse("<a href='download/key_file.pem/'></a>")
        return key.publickey().exportKey()

@login_required()
def base(request):
    received = Message.objects.all().filter(recipient=request.user.username, was_read=False)
    #if(len(received)>0):
    messageAlert = len(received)
        #= "<a href='/account/messages'>You have new messages!</a>"
    #else:
     #   messageAlert = "<a href='/account/messages'>You have no new messages.</a>"
    users = User.objects.exclude(id=request.user.id)

    if False: #len(Friend.objects.all()) > 0:
        friend = Friend.objects.get(current_user=request.user) #change back to get
        friends = friend.users.all()
    else:
        friends = Friend.objects.all()

    context = {'messageAlert':messageAlert, 'users':users, 'friends':friends}


    return render(request, 'base.html', context)

def register(request):
    if request.method == 'POST':

        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()  # creates User
            user.refresh_from_db()  # reload profile
            user.userprofile.user_type = int(form.cleaned_data['user_type'])
            user.userprofile.pub_key = gen_key()

            # print('user type:', int(form.cleaned_data['user_type']))
            user.save()
            user.refresh_from_db()
            # print(user.userprofile.user_type)


        return redirect("/account/display_key")
    else:
        form = RegistrationForm()

        # args = {'form': form}

    return render(request, 'accounts/reg_form.html', {'form': form})
def display_key(request):
    data = ""
    with open("key_file.pem") as myfile:
        data=data+myfile.read()+"</br><a href='/account/login'>Got it!</a>"
    os.remove("key_file.pem")
    return HttpResponse(data)


@login_required()  # Only logged in users can access this page
def view_profile(request, pk=None):
    if pk:
        user = User.objects.get(pk=pk)
    else:
        user = request.user
    args = {'user': user}
    return render(request, 'accounts/profile.html', args)


@login_required()
def edit_profile(request):
    if request.method == 'POST':
        form = EditProfileForm(request.POST, instance=request.user)

        if form.is_valid():
            form.save()
            return redirect('/account')  # change back to /account/profile
    else:
        form = EditProfileForm(instance=request.user)

    return render(request, 'accounts/change_password.html', {'form': form})


@login_required()
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(data=request.POST, user=request.user)

        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            return redirect('/account/profile')
        else:
            return redirect('/account/change-password')  # If it change was invalid
    else:
        form = PasswordChangeForm(user=request.user)
        # args = {'form': form} this is not cool
        return render(request, 'accounts/edit_profile.html', {'form': form})


@login_required()
def messages(request):
    sent = Message.objects.all().filter(sender=request.user.username)
    received = Message.objects.all().filter(recipient=request.user.username)
    context = {'sent': sent, 'received': received}
    return render(request, 'accounts/messages.html', context)


@login_required()
def sendMessage(request):
    if request.method == 'POST':
        message = Message(send_date=datetime.datetime.now(), sender=request.user.username)
        form = MessageForm(request.POST, instance=message)
        u1 = User.objects.get(username=request.POST['recipient'])
        # mt = RSA.importKey(UserProfile.objects.get(user=u1).pub_key).encrypt(str(form['message_text']).encode('utf-8'), 32)#form['message_text']#UserProfile.objects.get(user=u1).get_key().encrypt(str(form['message_text']).encode('utf-8'), 32)
        if(form.is_valid()):
            a = form.save()
            # a.message_text = mt
            # a.save()
        return redirect('/account/messages')
    else:
        form = MessageForm()
        args = {'form': form}
        return render(request, 'accounts/sendMessage.html', args)

@login_required()
def individualMessage(request, message_id, delete):
        message = Message.objects.get(pk=message_id)
        if(delete):
            message.delete()
            return redirect("/account/messages/")

        else:
            if(message.recipient==request.user.username):
                message.was_read = True
                message.save()
            # if request.method=='POST':
            #     message.message_text = UserProfile.objects.get(user=request.user).get_key().decrypt(bytes(message.message_text, 'utf-8'))
            return render(request,"accounts/individualMessage.html", {'message':message})


@login_required()
def reports(request):
    the_user = UserProfile.objects.get(user=request.user)
    if(the_user.is_site_manager):
        public_reports = Report.objects.all()
        return render(request, "accounts/reports.html", {'public_reports':public_reports})

    else:
        # public reports
        public_reports = list(Report.objects.all().filter(private_report=False))
        # group reports
        group_reports = []
        my_groups = Group.objects.all().filter(permissions__in=[request.user])
        for my_group in my_groups:
            for my_report in my_group.reports.all():
                group_reports.append(my_report)
        # my reports
        my_reports = Report.objects.all().filter(owner=request.user)
        return render(request, "accounts/reports.html", {'public_reports':public_reports,'group_reports':group_reports, 'my_reports':my_reports})


@login_required
def individualReport(request, report_id, delete=False):
    report = Report.objects.get(pk=report_id)

    # maybe have a button to redirect

    # form = FileFieldForm(request.POST, request.FILES)
    # if form.is_valid():
    #     files = request.FILES.getlist('files_attached')
    #     for f in files:
    #         report.files_attached.save(f.name, f, save=True)
    #         report.file_names.append(report.files_attached.name)
    if(delete):
        report.delete()
        return redirect("/account/reports/")
    else:
        return render(request, "accounts/individual_report.html", {'report':report})


def individualReportApi(request, report_id, delete=False):
    report = Report.objects.get(pk=report_id)
    json_report = serializers.serialize('json', [report]) # use list of just report because argument has to be iterable
    return JsonResponse(json_report, safe=False)


def getFilesAttachedToIndividual(request, report_id):
    report = Report.objects.get(pk=report_id)
    files_attached = json.dumps(report.file_names)
    return JsonResponse(files_attached, safe=False)
  
  
@login_required
def attachToIndividualReport(request, report_id):
    if request.method == 'POST':

        report = Report.objects.get(pk=report_id)
        form = FileFieldForm(request.POST, request.FILES, instance=report)

        if form.is_valid():
            files = request.FILES.getlist('files_attached')
            for f in files:
                report.files_attached.save(f.name, f, save=True)
                report.file_names.append(report.files_attached.name)
            form.save()
            return redirect('/account/reports')
        else:
            print('is not valid')

    else:
        form = FileFieldForm()
        args = {'form': form}
        return render(request, 'accounts/submitReport.html', args)


@login_required
def submitReport(request):
    the_user = UserProfile.objects.get(user=request.user)
    if the_user.is_investor():
        return redirect('/account/home')

    if request.method == 'POST':

        report = Report(owner=request.user)
        form = ReportForm(request.POST, request.FILES, instance=report)

        if form.is_valid():
            files = request.FILES.getlist('files_attached')
            for f in files:
                report.files_attached.save(f.name, f, save=True)
                report.file_names.append(report.files_attached.name)
            form.save()
            return redirect('/account/reports')
        else:
            print('is not valid')

    else:
        form = ReportForm()
        args = {'form': form}
        return render(request, 'accounts/submitReport.html', args)


@login_required
def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            print('is valid')
            return redirect('/account/home')
        print('is not valid')
    else:
        form = DocumentForm()
    return render(request, 'accounts/model_form_upload.html', {'form': form})


@login_required
def download_file(request, filename):
    # needs more permision checking
    with open('./media/' + filename, 'rb') as file:
        response = HttpResponse(file.read())
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment; filename="' + filename + '"'
    return response


@login_required
def get_queryset(request):
    keywords = request.GET.get('q').split() # q is what is entered into search box
    if keywords:
        # public reports
        public_reports = Report.objects.all().filter(private_report=False)
        # group reports
        my_groups = Group.objects.all().filter(permissions__in=[request.user])
        for my_group in my_groups:
            public_reports = public_reports | my_group.reports.all()
        # my reports
        my_reports = Report.objects.all().filter(owner=request.user)

        visible_reports = my_reports | public_reports

        results = visible_reports.filter(company_name__icontains=keywords[0]) | visible_reports.filter(ceo__icontains=keywords[0]) | visible_reports.filter(sector__icontains=keywords[0]) | visible_reports.filter(industry__icontains=keywords[0]) | visible_reports.filter(current_projects__icontains=keywords[0]) | visible_reports.filter(the_timestamp__icontains=keywords[0]) | visible_reports.filter(company_location__icontains=keywords[0]) | visible_reports.filter(company_country__icontains=keywords[0])

        for i, k in enumerate(keywords):
            results = results | visible_reports.filter(company_name__icontains=keywords[i]) | visible_reports.filter(ceo__icontains=keywords[i]) | visible_reports.filter(sector__icontains=keywords[i]) | visible_reports.filter(industry__icontains=keywords[i]) | visible_reports.filter(current_projects__icontains=keywords[i]) | visible_reports.filter(the_timestamp__icontains=keywords[i]) | visible_reports.filter(company_location__icontains=keywords[i]) | visible_reports.filter(company_country__icontains=keywords[i])


        return render(request, 'accounts/search_results.html', {'report_list':results})


@login_required
def get_queryset_api(request):
    keywords = request.GET.get('q').split()
    if keywords:
        # public reports
        public_reports = Report.objects.all().filter(private_report=False)
        # group reports
        my_groups = Group.objects.all().filter(permissions__in=[request.user])
        for my_group in my_groups:
            public_reports = public_reports | my_group.reports.all()
        # my reports
        my_reports = Report.objects.all().filter(owner=request.user)

        visible_reports = my_reports | public_reports

        results = visible_reports.filter(company_name__icontains=keywords[0]) | visible_reports.filter(ceo__icontains=keywords[0]) | visible_reports.filter(sector__icontains=keywords[0]) | visible_reports.filter(industry__icontains=keywords[0]) | visible_reports.filter(current_projects__icontains=keywords[0]) | visible_reports.filter(the_timestamp__icontains=keywords[0]) | visible_reports.filter(company_location__icontains=keywords[0]) | visible_reports.filter(company_country__icontains=keywords[0])

        for i, k in enumerate(keywords):
            results = results | visible_reports.filter(company_name__icontains=keywords[i]) | visible_reports.filter(ceo__icontains=keywords[i]) | visible_reports.filter(sector__icontains=keywords[i]) | visible_reports.filter(industry__icontains=keywords[i]) | visible_reports.filter(current_projects__icontains=keywords[i]) | visible_reports.filter(the_timestamp__icontains=keywords[i]) | visible_reports.filter(company_location__icontains=keywords[i]) | visible_reports.filter(company_country__icontains=keywords[i])


        json_results = serializers.serialize('json', results)
        print(type(json_results))
        return JsonResponse(json_results, safe=False)




@login_required
def change_friends(request, operation, pk):
    friend = User.objects.get(pk=pk)

    if operation == 'add':
        Friend.make_friend(request.user, friend)
    elif operation == 'remove':
        Friend.lose_friend(request.user, friend)
    return redirect('/account/home')


@login_required()
def addGroup(request):
    if request.method == 'POST':
        group = Group(creator=request.user)
        form = GroupForm(request.POST, instance=group)
        if form.is_valid():
            form.save()
            group.permissions.add(request.user)
            the_user = UserProfile.objects.get(user=request.user)
            if the_user.is_site_manager:
                return redirect('/account/groups_manager')
            return redirect('/account/groups')
        else:
            messages.error(request, "Error")
    else:
        form = GroupForm()
    return render(request,'accounts/addGroup.html', {'form':form})

@login_required()
def groups_manager(request):
    groups = Group.objects.all()
    return render(request, "accounts/groups.html", {'groups':groups})

@login_required()
def groups(request):
    the_user = UserProfile.objects.get(user=request.user)
    if(the_user.is_site_manager):
        groups = Group.objects.all()
        return render(request, "accounts/groups.html", {'groups':groups})
    else:
        groups = Group.objects.all()
        my_groups = groups.filter(permissions__in=[request.user])
        args = {'groups':my_groups}
        return render(request, "accounts/groups.html", args)

@login_required()
def individualGroup(request, group_id, delete=False):
    group = Group.objects.get(pk=group_id)
    if(delete):
        group.delete()
        return redirect("/account/groups/")
    else:
        return render(request, "accounts/individual_group.html", {'group':group})

@login_required()
def addGroupMember(request, group_id):
    if request.method == 'POST':
        form = UserListForm(request.POST)
        user_selected = request.POST.getlist('options')
        group = Group.objects.get(pk=group_id)
        for item in user_selected:
            item_entity = UserProfile.objects.get(user=item)
            group.permissions.add(item_entity.user)
        return redirect('/account/individualGroup/'+str(group.id))
    else:
        form = UserListForm()
        group = Group.objects.get(pk=group_id)
        args = {'form':form, 'group':group}
        return render(request, 'accounts/addGroupMember.html', args)

@login_required()
def addGroupReport(request, group_id):
    if request.method == 'POST':
        report = Report()
        form = ReportForm(request.POST, request.FILES, instance=report)
        if form.is_valid():
            form.save()
            group = Group.objects.get(pk=group_id)
            group.reports.add(report)
            return redirect('/account/individualGroup/'+str(group.id))
        else:
            print('is not valid')
    else:
        form = ReportForm()
        args = {'form': form}
        return render(request, 'accounts/submitReport.html', args)


@login_required()

def removeGroupMember(request, group_id, user_id):
    group = Group.objects.get(pk=group_id)
    item_entity = User.objects.get(id=user_id)
    # item_entity = UserProfile.objects.get(user=item)
    group.permissions.remove(item_entity)
    return redirect('/account/individualGroup/' + str(group.id))


@login_required()
def editReport(request, report_id):
    report = Report.objects.get(pk=report_id)
    if request.method == 'POST':
        form = EditReportForm(request.POST, instance=report)

        if form.is_valid():
            form.save()
            # report = Report.objects.get(pk=report_id)
            return redirect('/account/individualReport/'+str(report_id))
    else:
        form = EditReportForm(instance=report)

    return render(request, 'accounts/editReport.html', {'form': form})

@login_required()
def smPermission(request):
    the_user = UserProfile.objects.get(user=request.user)
    if(the_user.is_site_manager):
        if request.method == 'POST':
            form = UserListForm(request.POST)
            user_selected = request.POST.getlist('options')
            for item in user_selected:
                item_entity = UserProfile.objects.get(user=item)
                item_entity.is_site_manager = True
                item_entity.user_type = 0
                item_entity.save()
            return redirect('/account/')
        else:
            form = UserListForm()
            args = {'form':form}
            return render(request, 'accounts/smPermission.html', args)
    else:
        return redirect('/account/')

@login_required()
def smSuspend(request):
    the_user = UserProfile.objects.get(user=request.user)
    if(the_user.is_site_manager):
        if request.method == 'POST':
            form = UserListForm(request.POST)
            user_selected = request.POST.getlist('options')
            for item in user_selected:
                item_entity = UserProfile.objects.get(user=item)
                item_entity.user.is_active = False
                item_entity.user.save()

            return redirect('/account/')
        else:
            form = UserListForm()
            args = {'form':form}
            return render(request, 'accounts/smSuspend.html', args)
    else:
        return redirect('/account/')

@login_required()
def smUnsuspend(request):
    the_user = UserProfile.objects.get(user=request.user)
    if(the_user.is_site_manager):
        if request.method == 'POST':
            form = InactiveForm(request.POST)
            user_selected = request.POST.getlist('options')
            for item in user_selected:
                item_entity = UserProfile.objects.get(user=item)
                item_entity.user.is_active = True
                item_entity.user.save()

            return redirect('/account/')
        else:
            form = InactiveForm()
            args = {'form':form}
            return render(request, 'accounts/smUnsuspend.html', args)
    else:
        return redirect('/account/')

