* What is the format of the reports?

A.8

* Users can remove themselves from a group, can they prevent themselves from being re-added

C.2.9

* Why shouldn't the server also encrypt files?

C.5(sorta)

* Who can edit reports?
* Can files be removed in the process of being edited
* Who can remove files
* Can the privacy level be edited?

F.2.4

* Can anyone with access decrypt a file, or only whoever encrypted it?

G.6

* Can users block other users from sending them messages?

G

* Should private messages include images, video, etc?
